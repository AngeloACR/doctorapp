const express = require('express');
const empresaRouter = express.Router();
const passport = require('passport');
const auth = require("../../users/auth/auth");
const async = require('async');
const Empresa = require('../models/empresa');

//**************************** USER CRUD************************************//
empresaRouter.post('/', auth, async (req, res) => {
	try {
  
	  const empresa = {
		username: req.body.username,
		email: req.body.mail,
		password: req.body.password,
		tipo: req.body.tipo,
	  };
  
	  	let newEmpresa = await Empresa.addEmpresa(user);  
	  res.status(200).json(newEmpresa);
	} catch (e) { 
		res.status(400).json(e.toString());
	}
});
  

// Delete user
empresaRouter.delete('/', auth, async (req, res, next) => {
		try {
  
	  	const id = req.params.id;
  
	  	let response = await Empresa.deleteEmpresa(id);  
	  	res.status(200).json(response);
	}
	catch (e) { 
		res.status(400).json(e.toString());
	}
});

// Update user, NEED TO IMPROVE
empresaRouter.put('/', auth, passport.authenticate('jwt', {session:false}), async (req, res, next) => {
	try{
		const updateData = req.body.updateData;
  
	  	let response = await Empresa.updateEmpresa(updateData);  
	  	res.status(200).json(response);
	}
	catch (e) { 
		res.status(400).json(e.toString());
	}

});

// Get User
empresaRouter.get('/', auth, async (req, res, next) => {
		try {
	  	let response = await Empresa.getEmpresas();  
		  res.status(200).json(response);
	}
	catch (e) { 
		res.status(400).json(e.toString());
	}
	
});



module.exports = empresaRouter;